
var gallery = document.getElementById("gallery");

fetch("json/gallery.json").then(function(res) {
  res.json().then(function(json) {
    json.forEach(function(el) {

      var galleryItem = document.createElement('a');
      
      galleryItem.setAttribute("class", "gallery-item");
      galleryItem.setAttribute("href", el.url);
      galleryItem.setAttribute("target", "_blank");

      var galleryImage = document.createElement('img');

      // Set some attributes...
      galleryImage.setAttribute("src", el.url);        // The url of the image
      galleryImage.setAttribute("alt", el.caption);    // The alternative text
      galleryImage.setAttribute("title", el.caption);  // The tooltip
      
      // Create a caption element...
      var caption = document.createElement('caption');
      
      // Add text content to caption
      caption.innerText = el.caption;

      // Append the image and caption to our gallery item container
      galleryItem.appendChild(galleryImage);
      galleryItem.appendChild(caption);
      
      // Append the gallery item to our gallery element
      gallery.appendChild(galleryItem);
    });
  });
});
